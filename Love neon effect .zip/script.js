document.getElementById('shineBtn').addEventListener('click', function() {
    const neonText = document.querySelector('.neon-text');
    neonText.classList.toggle('shine');
});